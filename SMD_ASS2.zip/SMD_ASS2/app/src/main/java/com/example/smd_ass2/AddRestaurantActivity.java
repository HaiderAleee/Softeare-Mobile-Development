package com.example.smd_ass2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddRestaurantActivity extends AppCompatActivity {
    EditText nameEditText;
    EditText locationEditText;
    EditText descriptionEditText;
    EditText phoneEditText;
    EditText ratingEditText;
    Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_restaurant);
        nameEditText = findViewById(R.id.edit_text_name);
        locationEditText = findViewById(R.id.edit_text_location);
        phoneEditText = findViewById(R.id.edit_text_phone);
        descriptionEditText = findViewById(R.id.edit_text_description);
        ratingEditText = findViewById(R.id.edit_text_rating);
        registerButton = findViewById(R.id.button_register);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString().trim();
                String location = locationEditText.getText().toString().trim();
                String phone = phoneEditText.getText().toString().trim();
                String description = descriptionEditText.getText().toString().trim();
                String rating = ratingEditText.getText().toString().trim();

                restaurants res=new restaurants(name,phone,location,description,rating);

                if (name.isEmpty()) {
                    nameEditText.setError("Restaurant name is required");
                } else if (location.isEmpty()) {
                    locationEditText.setError("Location is required");
                } else if (phone.isEmpty()) {
                    phoneEditText.setError("Phone number is required");
                } else if (description.isEmpty()) {
                    descriptionEditText.setError("Description is required");
                } else if (rating.isEmpty()) {
                    ratingEditText.setError("Rating is required");
                } else {
                    Intent intent = new Intent();
                    intent.putExtra("key", res);
                    setResult(RESULT_OK, intent);
                    finish();

                }
            }
        });

    }
}