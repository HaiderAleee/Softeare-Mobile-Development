package com.example.smd_ass2;
import java.io.Serializable;
public class restaurants implements Serializable {
    String name;
    String phone_number;
    String location;
    String description;
    String rating;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public restaurants(String name, String phone_number, String location, String description, String rating) {
        this.name = name;
        this.phone_number = phone_number;
        this.location = location;
        this.description = description;
        this.rating = rating;
    }
}


