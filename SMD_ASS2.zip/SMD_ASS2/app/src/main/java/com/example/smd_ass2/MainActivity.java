package com.example.smd_ass2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    RecyclerView.LayoutManager manager;
    RecyclerView.Adapter adp;
    Button add;
    ArrayList<restaurants> arr;
    final int register=1;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==register) {
            if(resultCode==RESULT_CANCELED) {
                Toast.makeText(this, "No data entered", Toast.LENGTH_SHORT).show();
            } else {
                if (data != null && data.hasExtra("key")) {
                    restaurants res = (restaurants) data.getSerializableExtra("key");
                    arr.add(res);
                    sortArrayListByRating();
                    adp.notifyDataSetChanged();
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add = findViewById(R.id.button);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddRestaurantActivity.class);
                startActivityForResult(intent, register);
            }
        });

        recyclerView=findViewById(R.id.list);
        recyclerView.setHasFixedSize(true);
        manager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
        arr= new ArrayList<>();
        arr.add(new restaurants("ChaiQawali","03000532572","Johartown","Behtreen","5"));
        arr.add(new restaurants("Grill Spot","03214543432","Wapda Town","owesome","5"));
        arr.add(new restaurants("Cheezious","03234543432","Johartown","Average","4"));
        arr.add(new restaurants("Salt n Pepper","03156784245","Defence","Extremely Overpriced","2"));
        arr.add(new restaurants("Kaifiyat","03000532572","PIA Road","Bohtttt Farig","1"));
        sortArrayListByRating();
        adp=new restaurantadapter(this,arr);
        recyclerView.setAdapter(adp);
    }

    private void sortArrayListByRating() {
        for (int i = 0; i < arr.size() - 1; i++) {
            for (int j = 0; j < arr.size() - i - 1; j++) {
                int rating1 = Integer.parseInt(arr.get(j).getRating());
                int rating2 = Integer.parseInt(arr.get(j + 1).getRating());
                if (rating1 < rating2) {
                    // Swap elements if they are in the wrong order
                    restaurants temp = arr.get(j);
                    arr.set(j, arr.get(j + 1));
                    arr.set(j + 1, temp);
                }
            }
        }
    }
}
