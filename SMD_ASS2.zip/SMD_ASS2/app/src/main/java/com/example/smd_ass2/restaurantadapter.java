package com.example.smd_ass2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class restaurantadapter extends RecyclerView.Adapter<restaurantadapter.ViewHolder> {

    ArrayList<restaurants> restaurants;
    public restaurantadapter(Context context, ArrayList<restaurants> list)
    {
        restaurants=list;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView rat;
        TextView nam;
        TextView loc;
        TextView phn;
        TextView des;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            rat=itemView.findViewById(R.id.rating);
            nam=itemView.findViewById(R.id.name);
            loc=itemView.findViewById(R.id.location);
            phn=itemView.findViewById(R.id.phone);
            des=itemView.findViewById(R.id.description);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent ,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.rat.setText(restaurants.get(position).getRating());
        holder.nam.setText(restaurants.get(position).getName());
        holder.loc.setText(restaurants.get(position).getLocation());
        holder.phn.setText(restaurants.get(position).getPhone_number());
        holder.des.setText(restaurants.get(position).getDescription());


    }

    @Override
    public int getItemCount() {
        return restaurants.size();
    }
}
